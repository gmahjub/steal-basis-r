
# alphavantager 0.1.0

Intial release of `alphavantager`, a R interface to the Alpha Vantage API. Learn more at https://www.alphavantage.co. 

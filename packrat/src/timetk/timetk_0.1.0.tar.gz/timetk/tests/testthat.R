library(testthat)
library(timetk)

test_check("timetk")
